# Blog Management Application

React + Express.js + MongoDB Atlas REST API assignment.

## Setup

1. Install Node.js.
2. In `server/.env`, replace the placeholder `MONGODB_URI` with your MongoDB Atlas connection string.
3. Terminal 1:
   ```bash
   cd server
   npm install
   npm start
   ```
4. Terminal 2:
   ```bash
   cd app
   npm install
   npm run dev
   ```
5. Open http://localhost:5173

## API
- GET `/api/posts`
- GET `/api/posts/:id`
- POST `/api/posts`
- PUT `/api/posts/:id`
- DELETE `/api/posts/:id`
