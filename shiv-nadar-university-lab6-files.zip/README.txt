Shiv Nadar University - Lab 6

1. Copy App.jsx, App.css, index.css and main.jsx into your Vite project's src folder.
2. In the project folder run: npm install
3. Run: npm install react-router-dom
4. Run: npm run dev
