import { useState } from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
import "./App.css";

function Dropdown({ title, items }) {
  const [open, setOpen] = useState(false);

  return (
    <div className="dropdown">
      <button onClick={() => setOpen(!open)}>
        {title} ▼
      </button>

      {open && (
        <div className="dropdown-menu">
          {items.map((item, index) => (
            <Link key={index} to={item.path} onClick={() => setOpen(false)}>
              {item.name}
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

function Page({ title }) {
  return (
    <main className="content">
      <h1>{title}</h1>
      <p>Welcome to the {title} section of Shiv Nadar University.</p>
    </main>
  );
}

function Home() {
  return (
    <main className="hero">
      <div className="hero-card">
        <p className="eyebrow">SHIV NADAR UNIVERSITY</p>
        <h1>Welcome to Shiv Nadar University</h1>
        <p>
          Explore academics, admissions, research, campus life and
          placement opportunities.
        </p>
      </div>
    </main>
  );
}

function App() {
  return (
    <BrowserRouter>
      <nav className="navbar">
        <Link to="/" className="logo">
          Shiv Nadar University
        </Link>

        <div className="menu">
          <Dropdown
            title="About Us"
            items={[
              { name: "Vision & Mission", path: "/vision" },
              { name: "Leadership", path: "/leadership" },
              { name: "Departments", path: "/departments" },
            ]}
          />

          <Dropdown
            title="Academics"
            items={[
              { name: "Undergraduate", path: "/undergraduate" },
              { name: "Postgraduate", path: "/postgraduate" },
              { name: "PhD", path: "/phd" },
            ]}
          />

          <Dropdown
            title="Admissions"
            items={[
              { name: "Eligibility", path: "/eligibility" },
              { name: "Application Process", path: "/application" },
              { name: "Important Dates", path: "/dates" },
            ]}
          />

          <Dropdown
            title="Research"
            items={[
              { name: "Research Areas", path: "/research" },
              { name: "Publications", path: "/publications" },
            ]}
          />

          <Link to="/campus">Campus Life</Link>
          <Link to="/placements">Placements</Link>
          <Link to="/contact">Contact Us</Link>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/vision" element={<Page title="Vision & Mission" />} />
        <Route path="/leadership" element={<Page title="Leadership" />} />
        <Route path="/departments" element={<Page title="Departments" />} />
        <Route path="/undergraduate" element={<Page title="Undergraduate" />} />
        <Route path="/postgraduate" element={<Page title="Postgraduate" />} />
        <Route path="/phd" element={<Page title="PhD" />} />
        <Route path="/eligibility" element={<Page title="Eligibility" />} />
        <Route path="/application" element={<Page title="Application Process" />} />
        <Route path="/dates" element={<Page title="Important Dates" />} />
        <Route path="/research" element={<Page title="Research Areas" />} />
        <Route path="/publications" element={<Page title="Publications" />} />
        <Route path="/campus" element={<Page title="Campus Life" />} />
        <Route path="/placements" element={<Page title="Placements" />} />
        <Route path="/contact" element={<Page title="Contact Us" />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
